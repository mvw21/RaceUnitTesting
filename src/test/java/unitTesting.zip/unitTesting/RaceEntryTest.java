package unitTesting;

import org.junit.Assert;
import org.junit.Test;

public class RaceEntryTest {
    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS RaceEntry

    @Test
    public void addMethodShouldWork(){
        UnitRider rider = new UnitRider("Gosho",new UnitMotorcycle("Yamaha",100,60.0));
        RaceEntry raceEntry = new RaceEntry();
        raceEntry.addRider(rider);
        Assert.assertEquals(1,raceEntry.getRiders().size());
    }

    @Test(expected = NullPointerException.class)
    public void riderEqualsNullThrowsException(){
        UnitRider rider = null;
        RaceEntry raceEntry = new RaceEntry();
        raceEntry.addRider(rider);
    }

    @Test(expected = IllegalArgumentException.class)
    public void existingRiderThrowsException(){
        UnitRider rider = new UnitRider("Gosho",new UnitMotorcycle("Yamaha",100,60.0));
        RaceEntry raceEntry = new RaceEntry();
        raceEntry.addRider(rider);
        raceEntry.addRider(rider);
    }

    @Test(expected = IllegalArgumentException.class)
    public void calculateHorsePowerWithLessThanTwoThrowsException(){
        UnitRider rider = new UnitRider("Gosho",new UnitMotorcycle("Yamaha",100,60.0));
        UnitRider rider1 = new UnitRider("Pesho",new UnitMotorcycle("Yamaha",200,60.0));
        RaceEntry raceEntry = new RaceEntry();
        raceEntry.calculateAverageHorsePower();
    }

    @Test
    public void calculateHorsePowerIsCorrect(){
        UnitRider rider = new UnitRider("Gosho",new UnitMotorcycle("Yamaha",100,60.0));
        UnitRider rider1 = new UnitRider("Pesho",new UnitMotorcycle("Yamaha",200,60.0));
        RaceEntry raceEntry = new RaceEntry();
        raceEntry.addRider(rider);
        raceEntry.addRider(rider1);
        double result = raceEntry.calculateAverageHorsePower();
        Assert.assertEquals(150.0,result,0);

    }

   @Test(expected = UnsupportedOperationException.class)
    public void unmodifiableCheck(){
       UnitRider rider = new UnitRider("Gosho",new UnitMotorcycle("Yamaha",100,60.0));
       UnitRider rider1 = new UnitRider("Pesho",new UnitMotorcycle("Yamaha",200,60.0));
       RaceEntry raceEntry = new RaceEntry();
       raceEntry.addRider(rider);
       raceEntry.addRider(rider1);
       raceEntry.getRiders().clear();

   }
}
